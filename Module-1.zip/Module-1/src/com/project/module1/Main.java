package com.project.module1;

public class Main {
	/*Enter your desired Directory path */
	public static final String path = "C:\\Users\\Chanukya\\eclipse-workspace.chandu\\Module-1"; 
	
	public static void main(String[] args) {
		Menus menu = new Menus();
		menu.introScreen();
		menu.mainMenu();
	}
	
}
